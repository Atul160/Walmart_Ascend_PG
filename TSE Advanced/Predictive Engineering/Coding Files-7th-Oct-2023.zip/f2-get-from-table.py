#!/usr/bin/env python
import snowflake.connector

#https://llyjsuh-aw46506.snowflakecomputing.com

# Gets the version
conn = snowflake.connector.connect(
    user = 'PYTHON_CON_2', #accountAdmin DDL
    password = 'Pass,123',
    account = 'llyjsuh-aw46506'
)
cur = conn.cursor()
cur2 = conn.cursor()

#tables -- schemas -- databases -- warehouses (n)
#SUPERMARKET.PRODUCTMANAGEMENT.CATEGORY
cur.execute("use WAREHOUSE COMPUTE_WH") #warehouse selection
cur.execute("use DATABASE SUPERMARKET") #database selection
cur.execute("use SCHEMA PRODUCTMANAGEMENT") #SCHEMA selection

cur.execute("insert into product values (7, 2, 'Potato', 25);") #boolean - 1, 0
cur.execute("select id, name from product")

rows = cur.fetchall()
#print(rows)
#looping
#playlist - multi songs
#rows - multi information
for singleRow in rows:
    print(singleRow)

cur.close()
conn.close()