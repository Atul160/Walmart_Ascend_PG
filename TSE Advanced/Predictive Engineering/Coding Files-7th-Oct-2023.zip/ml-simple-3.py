import pandas
from sklearn import linear_model

#read csv
data = pandas.read_csv("data.csv")

#create the axis
x = data [["Volume", "Weight"]] #input
y = data[["CO2"]] #prediction

#prediction

#create a graph with existing data
linear_model.LinearRegression().fit(x, y)

#actual predicion
volumn = 3000
wt = 2000

x = linear_model.LinearRegression().fit(x, y).predict([[volumn, wt]])
print(x)


