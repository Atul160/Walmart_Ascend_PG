#predict - historical
#Machine Learning - Learns - creates finding

#cricket batsman
#Kohli
#1st - Striker
#2nd - Runing end
#3rd -- 4th --- 11th

from scipy import stats

#x
position  = [1, 2, 3, 4, 6]
#y
score = [40, 45, 90, 45, 100]

#initiate ML - scipy
slope, intercept, r, p, std_error = stats.linregress(position, score) #linear regression

#predict - 5th
targetPosition = 5
preditScore = slope * targetPosition + intercept
print(preditScore);