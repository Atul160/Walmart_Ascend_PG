import numpy

speed = [98, 12, 38, 29, 94, 34, 55, 23, 60]
print("avg. speed : ", numpy.mean(speed)) #average

print("medain : ", numpy.median(speed)) #middle value
#arranges the data in asceending
#12, 23, 29, 34, 38, 55, 60, 94, 94

speed = [98, 12, 38, 29, 94, 34, 55, 23, 60, 100]
print("medain : ", numpy.median(speed)) #middle value
#arranges the data in asceending
#12, 23, 29, 34, 38, 55, 60, 94, 94, 100
#38 + 55 = 93/2 = 98
