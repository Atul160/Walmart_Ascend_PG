#!/usr/bin/env python
import snowflake.connector

age = 20
name = "ashok"

#CONNECT TO THE SNOWFLAKE - user, password, account
conn = snowflake.connector.connect(
    user = 'PYTHON_CON_2',
    password = 'Pass,123',
    account = 'llyjsuh-aw46506'
)

#cursor - functionality snowflake - responsible for query execute
cr = conn.cursor()

cr.execute("select current_version()") #version of the snowflake

row = cr.fetchone() #return values from the above query

print(row)

cr.close()
conn.close()